package com.example.itada4_b34_assignment_midrand;

import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import java.util.ArrayList;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import java.util.List;
import androidx.annotation.Nullable;

public class sqllite_database extends SQLiteOpenHelper {

    // Database
    static final String DB_NAME = "AYIG.DB";

    // Table
    public static final String TABLE_NAME = "AYIG";

    // database version
    static final int DB_VERSION = 1;

    // Columns
    public static final String _ID = "_id";
    public static final String USERNAME = "username";
    public static final String EMAIL = "email";
    public static final String PASSWORD = "password";
    public static final String TYPE = "type";
    public static final String ACTIVITY = "activity";
    public static final String EVENT = "event";


    // Creating table
    private static final String CREATE_TABLE = "create table " + TABLE_NAME + "(" + _ID
            + " INTEGER PRIMARY KEY AUTOINCREMENT, " + USERNAME + " TEXT NOT NULL, " + EMAIL + " TEXT NOT NULL, " + PASSWORD + " TEXT NOT NULL, " + TYPE + " TEXT NOT NULL, "+ EVENT + " TEXT);";

    public sqllite_database(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }



}
