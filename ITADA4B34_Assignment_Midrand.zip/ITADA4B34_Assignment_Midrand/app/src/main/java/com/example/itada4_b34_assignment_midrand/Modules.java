package com.example.itada4_b34_assignment_midrand;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

public class Modules {
    sqllite_database databaseHelper;
    //Registering User
    public void AddUser(UserModule user)
    {
        databaseHelper = new sqllite_database(null);
        SQLiteDatabase db=databaseHelper.getWritableDatabase(); ContentValues contentValues=new ContentValues();
        contentValues.put(databaseHelper.USERNAME,user.getUsername());
        contentValues.put(databaseHelper.EMAIL,user.getEmail());
        contentValues.put(databaseHelper.TYPE,user.getType());
        contentValues.put(databaseHelper.PASSWORD,user.getPassword());
        db.insert(databaseHelper.DB_NAME,null,contentValues);
        db.close();
    }

    //Updating User
    public int updateUser(UserModule user)
    {
        SQLiteDatabase db = databaseHelper.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(databaseHelper.USERNAME,user.getUsername());
        contentValues.put(databaseHelper.EMAIL,user.getEmail());
        contentValues.put(databaseHelper.TYPE,user.getType());
        contentValues.put(databaseHelper.PASSWORD,user.getPassword());
        db.insert(databaseHelper.DB_NAME,null,contentValues);
        db.close();
        return db.update(databaseHelper.DB_NAME, contentValues, databaseHelper._ID + "=?", new String[]{String.valueOf(user.getId())});
    }

    //Removing user
    public void deleteUser(String id)
    {
        databaseHelper = new sqllite_database(null);
        SQLiteDatabase db=databaseHelper.getWritableDatabase();
        db.delete(databaseHelper.DB_NAME,databaseHelper._ID+"=?",new String[]{id});
        db.close();
    }

    //Returning a user
    public UserModule getUser(int id)
    {
        databaseHelper = new sqllite_database(null);
        SQLiteDatabase db=databaseHelper.getReadableDatabase();
        Cursor cursor=db.query(databaseHelper.DB_NAME,new String[]{databaseHelper._ID,databaseHelper.USERNAME,databaseHelper.EMAIL,databaseHelper.USERNAME,databaseHelper.PASSWORD},databaseHelper._ID+" = ?",new String[]{String.valueOf(id)},null,null,null);
        if(cursor!=null)
        {
            cursor.moveToFirst();
        }
        UserModule user =new UserModule(cursor.getString(0),cursor.getString(1),cursor.getString(2),cursor.getString(3),cursor.getString(4));
        db.close();
        return user;
    }

}
